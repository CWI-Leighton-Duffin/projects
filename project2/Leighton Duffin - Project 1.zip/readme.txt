site menu/navigation - index.html | quotes.html
banner/logo - index.html
external css - css/quotes.css | css/bootstrap.css
Home Page - index.html
2nd page - quotes.html
Calculation JavaScript - js/quotes.html
Date JavaScript = js/index.html

Calculation Javascript
On the quotes page you'll see inputs for attendees as well as buttons for selecting needed equipment. After selecting the desired options you press Calculate Quote and the quote amount is displayed. If you provide invalid data appropriate error messages are displayed.

Date JavaScript
On the main page you'll see it's displaying today's date. It also displays whether they're open or not depending on what day it is and what hour it is.